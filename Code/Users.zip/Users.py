import json
import os
import boto3
from boto3.dynamodb.conditions import Key, Attr

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')

def register(event, context):
    # Get the DynamoDB table name from environment variables
    table_name = os.environ['USER_TABLE_NAME']
    print(event)
    # Extract user data from the request
    body = json.loads(event['body'])
    name = body.get('name')
    email = body.get('email')
    password = body.get('password')
    psid = body.get('psid')
    
    # Reference to the DynamoDB table
    table = dynamodb.Table(table_name)
    
    # Check if email or psid already exists
    response = table.scan(
        FilterExpression=Attr('email').eq(email) | Attr('psid').eq(psid)
    )
    
    if response['Items']:
        return {
            "statusCode": 400,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST,OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({"message": "User with the same email or psid already exists"})
        }
    
    # Save user data to DynamoDB
    table.put_item(
        Item={
            'email': email,
            'name': name,
            'password': password,
            'psid': psid
        }
    )
    
    return {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type"
        },
        "body": json.dumps({"message": "User registered successfully"})
    }

def login(event, context):
    print(event)
    # Get the DynamoDB table name from environment variables
    table_name = os.environ['USER_TABLE_NAME']
    table = dynamodb.Table(table_name)
    # Extract login credentials from the request
    body = json.loads(event['body'])
    print(body)
    
    # Ensure the key matches the table's key schema
    response = table.get_item(
        Key={
            'email': body['email']
        }
    )
    
    if 'Item' in response:
        user = response['Item']
        # Add your logic to verify password and other authentication steps
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST,OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({"message": "Login successful"})
        }
    else:
        return {
            "statusCode": 401,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST,OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({"message": "Invalid email or password"})
        }