import json
import boto3
import os
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['QUESTION_TABLE_NAME'])

def delete_question(event, context):
    print(event)
    # Extracting user ID from the event (assuming it's passed in the request context)
    email = event['queryStringParameters']['user_email']

    # Extracting the question_id from the path parameters
    question_id = event['queryStringParameters']['question_id']

    # Get the item from DynamoDB to check ownership
    try:
        response = table.get_item(
            Key={'question_id': question_id}
        )
    except ClientError as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'DELETE'
            },
            'body': json.dumps({'error': 'Error fetching question data'})
        }

    if 'Item' not in response:
        return {
            'statusCode': 404,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'DELETE'
            },
            'body': json.dumps({'error': 'Question not found'})
        }

    question_item = response['Item']

    # Check if the requester is the owner of the question
    if question_item['email'] != email:
        return {
            'statusCode': 403,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'DELETE'
            },
            'body': json.dumps({'error': 'Unauthorized to delete this question'})
        }

    # Delete the item from DynamoDB
    try:
        table.delete_item(
            Key={'question_id': question_id},
            ConditionExpression='attribute_exists(question_id)'
        )
    except ClientError as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'DELETE'
            },
            'body': json.dumps({'error': 'Error deleting question'})
        }

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'DELETE'
        },
        'body': json.dumps({'message': 'Question deleted successfully'})
    }
