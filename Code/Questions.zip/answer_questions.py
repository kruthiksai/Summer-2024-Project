import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['QUESTION_TABLE_NAME'])

def answer_question(event, context):
    try:
        # Extract necessary fields from event
        print(event)
        body = json.loads(event['body']) if 'body' in event else event
        question_id = body.get("question_id")
        email = body.get("email")
        answer_text = body.get("answer")
        
        # Check if required fields are present
        if not (question_id and email and answer_text):
            return {
                "statusCode": 400,
                "body": json.dumps({"message": "Missing required fields: question_id, email, answer"}),
                "headers": {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type",
                    "Access-Control-Allow-Methods": "OPTIONS,POST"
                }
            }
        
        # Create answer object with email, current time, and answer
        answer_object = {
            "email": email,
            "time": datetime.utcnow().isoformat(),
            "answer": answer_text
        }
        
        # Update item in DynamoDB
        response = table.update_item(
            Key={'question_id': question_id},
            UpdateExpression="SET answers = list_append(if_not_exists(answers, :empty_list), :new_answer)",
            ConditionExpression="attribute_exists(question_id)",
            ExpressionAttributeValues={
                ':new_answer': [answer_object],
                ':empty_list': []
            },
            ReturnValues="UPDATED_NEW"
        )
        
        # Return success response
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Answer posted successfully", "updated_attributes": response['Attributes']}),
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS,POST"
            }
        }
    
    except Exception as e:
        # Log the exception for debugging
        print(f"Error: {str(e)}")
        
        # Return error response
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "Failed to post answer", "error": str(e)}),
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS,POST"
            }
        }
