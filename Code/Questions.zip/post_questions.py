import json
import boto3
import base64
import uuid
import os
from datetime import datetime

# Initialize DynamoDB and S3 clients
dynamodb = boto3.resource('dynamodb')
table_name = os.environ['QUESTION_TABLE_NAME']
table = dynamodb.Table(table_name)  # Replace with your DynamoDB table name
s3 = boto3.client('s3')

def post_question(event, context):
    # Parse the incoming request body
    
    body = json.loads(event['body'])
    print(event)
    question = body.get('question')
    email = body.get('email')
    images_base64 = body.get('image', [])  # Assuming 'imagesBase64' is an array of base64-encoded images
    
    # List to store S3 image paths
    image_paths = []
    
    # Process each image
    for index, image_base64 in enumerate(images_base64):
        print("Processing image")
        # Decode base64 data
        image_data = base64.b64decode(image_base64)
        
        # Generate a unique filename using UUID
        file_key = str(uuid.uuid4())
        file_name = f"{file_key}.jpg"  # Assuming JPEG format, adjust as needed
        
        # Upload image data to S3
        s3.put_object(Bucket=os.environ['IMAGE_BUCKET_NAME'], Key=file_name, Body=image_data)
        
        # Construct S3 URL for the uploaded image
        s3_url = f"https://{os.environ['IMAGE_BUCKET_NAME']}.s3.amazonaws.com/{file_name}"
        image_paths.append(s3_url)
    
    # Save question, email, and image paths to DynamoDB
    question_id = str(uuid.uuid4())  # Generate a unique question ID
    response = table.put_item(
        Item={
            'question_id': question_id,
            'question': question,
            'email': email,
            'image_paths': image_paths,
            "time": datetime.utcnow().isoformat()  # Store list of S3 URLs in DynamoDB
            # Add more attributes as needed
        }
    )
    
    # Return success response with CORS headers
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST'
        },
        'body': json.dumps('Question posted successfully')
    }
