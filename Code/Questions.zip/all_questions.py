import json
import boto3
import os

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['QUESTION_TABLE_NAME'])

def all_question(event, context):
    try:
        # Scan DynamoDB table to retrieve all items (questions)
        print(table)
        response = table.scan()
        
        # Extract items (questions) from response
        questions = response['Items']
        
        # Format response body
        response_body = {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',  # Allow all origins
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',  # Allow specific methods
                'Access-Control-Allow-Headers': 'Content-Type'  # Allow specific headers
            },
            'body': json.dumps(questions)
        }
        
        return response_body
    
    except Exception as e:
        # Log the exception for debugging
        print(f"Error: {str(e)}")
        
        # Return error response
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',  # Allow all origins
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',  # Allow specific methods
                'Access-Control-Allow-Headers': 'Content-Type'  # Allow specific headers
            },
            'body': json.dumps({'message': 'Failed to retrieve questions', 'error': str(e)})
        }
